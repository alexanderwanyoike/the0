# Multi-Test Bot

This is a test bot that can run both bot and backtest entrypoints with proper termination.