def main(id, config):
    """Simple Python backtest for testing."""
    print(f"Python backtest starting with ID: {id}")
    print(f"Config: {config}")
    
    return {
        "status": "success",
        "results": {
            "metrics": {
                "total_return": 0.15,
                "sharpe_ratio": 1.2,
                "win_rate": 0.6,
                "total_trades": 10
            },
            "plots": [],
            "tables": []
        }
    }