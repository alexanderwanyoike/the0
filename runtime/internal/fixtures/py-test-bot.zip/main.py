import logging
import time


def main(id, config):
    """Simple Python bot for testing."""
    print(f"Python bot starting with ID: {id}")
    print(f"Config: {config}")
    
    # Keep running as a long-running bot
    while True:
        print("Python bot is running...")
        time.sleep(5)
