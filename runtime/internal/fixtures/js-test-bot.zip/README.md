# Custom Bot Example

This repository demonstrates how to create a custom trading bot compatible with The0 platform.

## Project Structure

- `main.py` - Main trading bot implementation
- `backtest.py` - Backtesting implementation
- `bot-config.yaml` - Bot configuration and metadata
- `schema.json` - JSON schema defining bot and backtest parameters

## Creating Your Custom Bot

1. **Configure Bot Settings**
   Edit `bot-config.yaml` to define your bot's metadata:
   ```yaml
   name: your-bot-name
   description: Your bot description
   version: 1.0.0
   author: Your Name
   entrypoint: main.py
   backtest: backtest.py
   ```

2. **Implement Trading Logic**
   Modify `main.py` to implement your trading strategy:
   ```python
   def main(id: str, config: Dict[str, Any]) -> None:
       # Your trading logic here
       return {
           "status": "success",
           "message": "Trading execution status"
       }
   ```

3. **Implement Backtesting**
   Use `backtest.py` to test your strategy with historical data:
   ```python
   def main(config: Dict[str, Any]) -> None:
       # Your backtest logic here
       return {
           "status": "success",
           "results": {
               "metrics": {
                   "total_return": 0.0,
                   "sharpe_ratio": 0.0,
                   "max_drawdown": 0.0,
                   "win_rate": 0.0
               },
               "plots": []
           }
       }
   ```

4. **Define Parameters**
   Update `schema.json` to specify required parameters:
   - Bot configuration schema
   - Backtest configuration schema including:
     - start_date
     - end_date
     - initial_balance
     - trading_pair

## Bot Interface

### Trading Bot
The main trading function accepts a configuration dictionary and returns a status object:
```python
{
    "status": "success" | "failure",
    "message": str
}
```

### Backtest
The backtest function accepts configuration and returns performance metrics and visualization data:
```python
{
    "status": "success",
    "results": {
        "metrics": dict,
        "plots": list
    }
}
```

## Getting Started

1. Clone this repository
2. Modify the bot configuration in `bot-config.yaml`
3. Implement your trading strategy in `main.py`
4. Implement your backtesting logic in `backtest.py`
5. Test your bot using the backtest functionality

