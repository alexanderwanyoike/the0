const { log } = require('console');

// Configure logging
console.log = console.log.bind(console);
const logging = {
    info: (msg) => console.log(msg)
};

async function main(id, config) {
    /**
     * Simple hello world bot that logs bot id and config.
     */
    
    logging.info(`Hello World! Bot ID: ${id}`);
    logging.info(`Bot Config: ${JSON.stringify(config)}`);


    return {
        status: "success",
        message: "Hello world bot executed successfully"
    };
}

module.exports = main;
