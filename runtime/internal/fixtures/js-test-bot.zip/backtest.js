// Remove external dependencies - use built-in Math functions

/**
 * Main function of your backtesting bot.
 * @param {string} id - The identifier
 * @param {Object} config - Configuration object
 * @returns {Object} Results of the backtest
 */
function main(id, config) {
    // Simplified metrics
    const metrics = {
        total_return: Math.random() * 0.5 - 0.1,
        sharpe_ratio: Math.random() * 3,
        max_drawdown: -Math.random() * 0.3
    };

    // Single plot
    const plots = [];
    const numPoints = 100;
    const x = [];
    const y = [];
    
    // Generate x values
    for (let i = 0; i < numPoints; i++) {
        x.push(i);
    }
    
    // Generate y values - simple sine wave with noise
    for (let i = 0; i < numPoints; i++) {
        y.push(Math.sin(i * 0.1) + (Math.random() - 0.5) * 0.5);
    }
    
    plots.push({
        data: [
            {
                x: x,
                y: y,
                type: "scatter",
                mode: "lines",
                name: "Portfolio Performance",
                line: { 
                    color: "blue",
                    width: 2
                }
            }
        ],
        layout: {
            title: "Portfolio Performance Over Time",
            xaxis: { title: "Time" },
            yaxis: { title: "Returns" }
        }
    });

    // Single table
    const tables = [
        {
            title: "Trade Summary",
            data: [
                {
                    trade_id: 1,
                    entry_date: "2024-01-01",
                    exit_date: "2024-01-02",
                    symbol: "AAPL",
                    entry_price: 150.25,
                    exit_price: 152.80,
                    profit_loss: 255.0,
                    return_pct: 1.70
                },
                {
                    trade_id: 2,
                    entry_date: "2024-01-02",
                    exit_date: "2024-01-05",
                    symbol: "TSLA",
                    entry_price: 240.50,
                    exit_price: 235.20,
                    profit_loss: -265.0,
                    return_pct: -2.20
                }
            ]
        }
    ];

    return {
        status: "success",
        results: {
            metrics,
            plots,
            tables
        }
    };
}

module.exports = { main };
